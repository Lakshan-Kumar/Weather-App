
class DailyWeather {
  String date;
  String imagePath;
  double avgTemp;
  String status;

  DailyWeather({
    required this.date,
    required this.imagePath,
    required this.avgTemp,
    required this.status,
  });

  factory DailyWeather.fromJson(day) {

    return DailyWeather(
        date: day['date'],
        imagePath: "https:" + day['day']['condition']['icon'],
        status: day['day']['condition']['text'],
        avgTemp: day['day']['avgtemp_c']);
  }
}
