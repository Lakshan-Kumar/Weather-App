import 'weather_information.dart';

class WeatherDataModel {
  final String cityName;
  final DateTime date;
  final List<DailyWeather> listOfDays;

  WeatherDataModel({
    required this.cityName,
    required this.date,
    required this.listOfDays,
  });

  factory WeatherDataModel.fromJson(json) {
    List<DailyWeather> days = [];
    for (var day in json['forecast']['forecastday']) {
      days.add(
        DailyWeather.fromJson(day),
      );
    }

    return WeatherDataModel(
      cityName: json['location']['name'],
      date: DateTime.parse(json['current']['last_updated']),
      listOfDays: days,
    );
  }
}
