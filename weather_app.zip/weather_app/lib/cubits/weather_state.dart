import '../../models/weather_forecast.dart';

class WeatherState {}

class InitialWeather extends WeatherState {}

class WeatherLoadedState extends WeatherState {
  final WeatherDataModel weatherModel;
  final int dayNumber;

  WeatherLoadedState({required this.weatherModel,required this.dayNumber});
}

class WeatherError extends WeatherState {
  final String errorMsg;

  WeatherError({required this.errorMsg});
}
