import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../models/weather_forecast.dart';
import '../../services/weather_api.dart';
import 'weather_state.dart';

class WeatherCubit extends Cubit<WeatherState> {
  WeatherCubit() : super(InitialWeather());

  getCurrentWeather({required String city,required int dayNumber}) async {
    try {
      WeatherDataModel weatherModel =
          await WeatherAPI(dio: Dio()).getCurrentWeather(city: city);
      emit(WeatherLoadedState(weatherModel: weatherModel,dayNumber: dayNumber));
    } catch (e) {}
  }
}
