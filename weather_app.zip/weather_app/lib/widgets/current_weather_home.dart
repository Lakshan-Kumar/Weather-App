import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class CurrentWeather extends StatefulWidget {
  const CurrentWeather({super.key});

  @override
  State<CurrentWeather> createState() => _CurrentWeatherState();
}

class _CurrentWeatherState extends State<CurrentWeather> {
  var cityName = '';
  var temp = 0.0;
  var lat = 0.0;
  var lon = 0.0;
  var weatherType = '';
  var description = '';
  var humidity = 0;

  @override
  void initState() {
    super.initState();
    requestLocationPermission();
  }

  void requestLocationPermission() async {
    try {
      await getUserLocation();
      await getData();
      setState(() {});
    } catch (e) {
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/icons/bg1.jpg"),
              fit: BoxFit.fill,
            ),
          ),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    cityName,
                    style: const TextStyle(
                        fontSize: 40,
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        height: -1),
                  ),
                  const Padding(
                    padding:
                        EdgeInsets.symmetric(vertical: 20.0, horizontal: 60),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          // Add padding to the left
                          padding: EdgeInsets.only(
                              right: 30.0), // Adjust padding value
                          child: SizedBox(
                            width: 102,
                            height: 150,
                            child: Icon(Icons.cloud,
                                size: 150, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    '${temp.toString()} °C',
                    style: const TextStyle(
                      fontSize: 40,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      height: 1.5,
                      letterSpacing: 1.0,
                    ),
                  ),
                  Text(
                    weatherType,
                    style: const TextStyle(
                      fontSize: 28,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      height: 1.5,
                      letterSpacing: 1.0,
                    ),
                  ),
                  Text(
                    description,
                    style: const TextStyle(
                        fontSize: 28,
                        color: Colors.white,
                        height: 1.5,
                        letterSpacing: 1.0),
                  ),
                  Text(
                    'Humidity: ${humidity.toString()}%',
                    style: const TextStyle(
                        fontSize: 28,
                        color: Colors.white,
                        height: 2,
                        letterSpacing: 1.0),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      debugShowCheckedModeBanner: false,
    );
  }

  Future<void> getUserLocation() async {
    // ... (Location permission handling code from previous response)

    final Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    lat = position.latitude;
    lon = position.longitude;
  }

  Future<void> getData() async {
    if (lat == 0.0 || lon == 0.0) {
      await getUserLocation();
    }
    final dio = Dio();
    final response = await dio.get(
        'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=88278e68fe3476da032da526af6aa268&units=metric');
    temp = (response.data['main']['temp']);
    cityName = (response.data['name']);
    lat = (response.data['coord']["lat"]);
    lon = (response.data['coord']["lon"]);
    weatherType = (response.data['weather'][0]['main']);
    description = (response.data['weather'][0]['description']);
    humidity = (response.data['main']['humidity']);
  }
}
