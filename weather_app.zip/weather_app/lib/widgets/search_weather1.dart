import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled2/cubits/weather_cubit.dart';
import 'package:untitled2/widgets/search_weather2.dart';
import '../main.dart';
import '../models/weather_forecast.dart';

class SearchWeather1 extends StatefulWidget {
  final WeatherDataModel model;

  const SearchWeather1({super.key, required this.model});

  @override
  State<SearchWeather1> createState() => _SearchWeather1State();
}

class _SearchWeather1State extends State<SearchWeather1> {
  int n = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          colors: [
            getColorTheme(widget.model.listOfDays[n].status),
            Colors.white
          ],
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: () {
                  setState(() {
                    if (0 < n) n--;
                    BlocProvider.of<WeatherCubit>(context).getCurrentWeather(
                        city: widget.model.cityName, dayNumber: n);
                  });
                },
                icon: Container(
                  height: 34,
                  width: 34,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(81),
                    color: Colors.white.withOpacity(.4),
                  ),
                  child: const Icon(Icons.keyboard_arrow_left_sharp, color: Colors.black, size: 30),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 20),
                height: 40,
                width: 140,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: Colors.white.withOpacity(.4),
                ),
                child: Text(
                  widget.model.listOfDays[n].date,
                  style: const TextStyle(
                      color: Colors.black,
                      fontSize: 18, fontWeight: FontWeight.w500),
                ),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    if (widget.model.listOfDays.length - 1 > n) n++;
                    BlocProvider.of<WeatherCubit>(context).getCurrentWeather(
                        city: widget.model.cityName, dayNumber: n);
                  });
                },
                icon: Container(
                  height: 35,
                  width: 35,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(80),
                    color: Colors.white.withOpacity(.4),
                  ),
                  child: const Icon(Icons.keyboard_arrow_right_sharp, color: Colors.black, size: 30),
                ),
              ),
            ],
          ),
          SearchWeather2(model: widget.model, n: n),
        ],
      ),
    );
  }
}
