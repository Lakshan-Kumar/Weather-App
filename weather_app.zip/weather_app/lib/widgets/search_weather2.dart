import 'package:flutter/material.dart';
import 'package:untitled2/models/weather_forecast.dart';class SearchWeather2 extends StatelessWidget {
  final WeatherDataModel model;
  final int n;

  const SearchWeather2({required this.model, required this.n, super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 30.0, horizontal: 12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                model.cityName,
                style: const TextStyle(color: Colors.black, fontSize: 36, fontWeight: FontWeight.w800, height: 4),
              ),
              SizedBox(
                height: 200,
                 child: Image.network(
                  model.listOfDays[n].imagePath,
                  fit: BoxFit.cover,
                ),
              ),
              Text(
                "${model.listOfDays[n].avgTemp.round()}°C",
                style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w700, height: 3),
              ),
              Text(
                model.listOfDays[n].status,
                style: const TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w600, height: 3),
              ),
            ],
          ),
        ),
      ),
    );
  }
}