import 'dart:developer';
import 'package:dio/dio.dart';
import '../models/weather_forecast.dart';

class WeatherAPI {
  final Dio dio;
  final String apiKey = "507ee2f45e3a4d8786765730242906";
  final String url = "https://api.weatherapi.com/v1";

  WeatherAPI({required this.dio});

  Future<WeatherDataModel> getCurrentWeather({required String city}) async {
    try {
      Response response =
          await dio.get("$url/forecast.json?key=$apiKey&q=$city&days=5");
      WeatherDataModel model = WeatherDataModel.fromJson(response.data);
      return model;
    } catch (e) {
      log(e.toString());
      throw('Error, try again');
    }
  }
}
