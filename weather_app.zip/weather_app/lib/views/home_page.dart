import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled2/cubits/weather_cubit.dart';
import 'package:untitled2/cubits/weather_state.dart';
import '../widgets/current_weather_home.dart';
import '../widgets/search_weather1.dart';
import 'search_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
          backgroundColor: const Color(0XFF43A7B9),
          title: const Text(style:
              TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
              "Weather"),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 10.0),
              child: IconButton(
                icon: const Icon(Icons.search_rounded,
                    color: Colors.white, size: 32),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) {
                        return const SearchPage();
                      },
                    ),
                  );
                },
              ),
            ),
          ]),
      body: BlocBuilder<WeatherCubit, WeatherState>(
        builder: (context, state) {
          if (state is WeatherError) {
            return Center(
              child: Text(
                style: const TextStyle(fontSize: 31),
                state.errorMsg,
              ),
            );
          } else if (state is WeatherLoadedState) {
            return SearchWeather1(model: state.weatherModel);
          } else {
            return const CurrentWeather();
          }
        },
      ),
    );
  }
}