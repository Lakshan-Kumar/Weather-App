import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled2/cubits/weather_cubit.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController city = TextEditingController(text: '');
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: const Color(0XFF43A7B9),
        title: const Text(
          "Search for a city",
          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_outlined, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: TextField(
            controller: city,
            onSubmitted: (value) async {
              if (value.isNotEmpty) {
                BlocProvider.of<WeatherCubit>(context)
                    .getCurrentWeather(city: value, dayNumber: 0);
                Navigator.pop(context);
              }
            },
            keyboardType: TextInputType.name,
            decoration: InputDecoration(
              contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 30),
              labelText: "Search",
              suffixIcon: IconButton(
                icon: const Icon(Icons.search_rounded, size: 32, color: Colors.black),
                onPressed: () {
                  if (city.text != '') {
                    BlocProvider.of<WeatherCubit>(context)
                        .getCurrentWeather(city: city.text, dayNumber: 0);
                    Navigator.pop(context);
                  }
                },
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
