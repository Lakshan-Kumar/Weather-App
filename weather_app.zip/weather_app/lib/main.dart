import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled2/cubits/weather_cubit.dart';
import 'package:untitled2/cubits/weather_state.dart';
import 'package:untitled2/views/home_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => WeatherCubit(),
      child: BlocBuilder<WeatherCubit, WeatherState>(
        builder: (context, state) => MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primarySwatch: state is WeatherLoadedState
                ? getColorTheme(state.weatherModel.listOfDays[state.dayNumber].status)
                : Colors.blue,
          ),
          home: const HomePage(),
        ),
      ),
    );
  }
}

MaterialColor getColorTheme(String condition) {
  switch (condition) {
    case 'Sunny':
      return Colors.orange;
    case 'Overcast':
    case 'Moderate rain':
    case 'Moderate or heavy rain shower':
    case 'Moderate or heavy rain with thunder':
    case 'Heavy rain':
      return Colors.blue;
    default:
      return Colors.grey;
  }
}
