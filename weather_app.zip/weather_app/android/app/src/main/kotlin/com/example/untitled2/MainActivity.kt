package com.example.Weather

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
